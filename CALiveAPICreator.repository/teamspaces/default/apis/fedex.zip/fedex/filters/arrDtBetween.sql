to_char(arrivaldate, 'yyyymmdd') between {yyyymmdd_from} and {yyyymmdd_to}
