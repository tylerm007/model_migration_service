# SECURITY
This folder contains definitions for security.
