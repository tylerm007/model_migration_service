# PIPELINE EVENTS
This folder contains definitions for pipeline events.
