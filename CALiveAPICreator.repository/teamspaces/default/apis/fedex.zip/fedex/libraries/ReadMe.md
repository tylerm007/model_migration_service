# LIBRARIES
This folder contains definitions for libraries and whether they are used.
