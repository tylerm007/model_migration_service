return [
  { value: '140', viewValue: 'FLT 140 (OAK-YVR)' },
  { value: '142', viewValue: 'FLT 142 (MEM-YVR)' },
  { value: '128', viewValue: 'FLT 128 (MEM-YYZ)' },
  { value: '132', viewValue: 'FLT 132 (MEM-YYZ)' },
  { value: '150', viewValue: 'FLT 150 (IND-YYZ)' },
  { value: '160', viewValue: 'FLT 160 (EWR-YYZ)' },
  { value: '232', viewValue: 'FLT 232 (MEM-YYZ)' },
  { value: '130', viewValue: 'FLT 130 (MEM-YMX)' },
  { value: '152', viewValue: 'FLT 152 (IND-YMX)' },
  { value: '138', viewValue: 'FLT 138 (MEM-YYC)' },
  { value: '236', viewValue: 'FLT 236 (MEM-YYC)' },
  { value: '120', viewValue: 'FLT 120 (MEM-YEG)' },
  { value: '8065', viewValue: 'FLT 8065 (MEM-YWG)' },
  { value: 'MC216', viewValue: 'FLT MC216 (MEM-YWG)' }
];
